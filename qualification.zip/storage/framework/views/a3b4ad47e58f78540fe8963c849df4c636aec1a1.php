
<script src="<?php echo e(asset('js/jquery/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery/jquery-ui.js')); ?>"></script>

<script src="<?php echo e(asset('js/popperjs/popper.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap/bootstrap.js')); ?>"></script>

<script src="<?php echo e(asset('js/highcharts/highcharts.js')); ?>"></script>
<script src="<?php echo e(asset('js/highcharts/highcharts-more.js')); ?>"></script>

<script src="<?php echo e(asset('js/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables/dataTables.responsive.min.js')); ?>"></script>




<script src="<?php echo e(asset('js/datatables/dataTables.buttons.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables/buttons.colVis.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables/buttons.flash.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables/buttons.html5.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables/buttons.print.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables/buttons.bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables/jszip.js')); ?>"></script>


<script src="<?php echo e(asset('js/moment/moment-with-locales.js')); ?>"></script>
<script src="<?php echo e(asset('js/tempusdominus-bootstrap-4.js')); ?>"></script>

<script src="<?php echo e(asset('js/metismenu/dist/metisMenu.js')); ?>"></script>
<script src="<?php echo e(asset('js/simplebar/dist/simplebar.js')); ?>"></script>
<script src="<?php echo e(asset('js/node-waves/dist/waves.js')); ?>"></script>

<script src="<?php echo e(asset('js/app.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\qualification\resources\views/components/scripts.blade.php ENDPATH**/ ?>