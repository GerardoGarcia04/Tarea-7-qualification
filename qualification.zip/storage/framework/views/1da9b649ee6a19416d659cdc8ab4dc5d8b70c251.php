

<?php $__env->startSection('header'); ?>
	<h4 class="pb-1">
		<?php echo app('translator')->get('auth.login_title'); ?>
	</h4>
	<h6 class="pb-2">
		<?php echo app('translator')->get('auth.login_subtitle'); ?>
	</h6>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
	<?php echo $__env->make('auth.login-fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
	<p class="pt-4 text-center">
		<?php if(Route::has('register')): ?>
			<?php echo app('translator')->get('auth.register_label'); ?>
			<a class="app-link" href="<?php echo e(route('register')); ?>">
				<i class='bx bxs-lock-alt'></i>
				<?php echo app('translator')->get('auth.register_link'); ?>
			</a>
		<?php endif; ?>
	</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qualification\resources\views/auth/login.blade.php ENDPATH**/ ?>