<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "type",
		"id" => "type",
		"class" => "form-control",
		"entity" => "assignments",
		"type" => "text",
		"defaultValue" => old("type") ?? ($assignment->type ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "qualification",
		"id" => "qualification",
		"class" => "form-control",
		"entity" => "assignments",
		"type" => "text",
		"defaultValue" => old("qualification") ?? ($assignment->qualification ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "date",
		"id" => "date",
		"class" => "form-control",
		"entity" => "assignments",
		"type" => "text",
		"defaultValue" => old("date") ?? ($assignment->date ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "course_input",
		"id" => "course_input",
		"class" => "form-control input-autocomplete",
		"entity" => "assignments",
		"type" => "input-autocomplete",
		"defaultValue" => old("course_input") ?? ($assignment->course_input ?? ""),
		"required" => "true",
		"data-source" => "/getbyparam",
		"data-hidden-id" => "course_id",
		"data-hidden-value" => old("course_id") ?? ($assignment->course_id ?? ""),
		"translations" => "assignments.course_id",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\qualification\resources\views/assignments/fields.blade.php ENDPATH**/ ?>