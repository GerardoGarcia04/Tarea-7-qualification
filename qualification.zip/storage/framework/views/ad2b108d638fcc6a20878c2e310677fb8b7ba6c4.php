<?php $model = ${Str::singular($params["entity"])}; ?>
<div class="modal <?php echo e($params["entity"] ?? 'modal'); ?>-modal" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					<?php echo e(__(($params["translations"] ?? $params["entity"]).'.title_'.($model === null ? 'add' : 'edit'))); ?>

				</h5>
				<button type="button" class="btn btn-default" data-bs-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<?php if($model === null): ?>
					<?php echo e(Form::open(['id' => $params["entity"].'-quickmodal', 'route' => $params["entity"].'.store'])); ?>

				<?php else: ?>
					<?php echo e(Form::open(['id' => $params["entity"].'-quickmodal', 'route' => [$params["entity"].'.update', $model->id], 'method' => 'POST'])); ?>

					<?php echo method_field('PUT'); ?>
					<input type="hidden" name="id" value="<?php echo e($model->id); ?>">
				<?php endif; ?>
				<div class="message-container"></div>
				<?php echo $__env->make(($params['resource'] ?? str_replace('_', '-', $params['entity'])) . '.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php echo e(Form::close()); ?>

			</div>
			<div class="modal-footer">
				<?php echo e(Form::button(__("Save"), ["class" => "btn btn-primary", "onclick" => "saveQuickAdd('".base64_encode(json_encode($params))."')"])); ?>

				<?php echo e(Form::button(__("Cancel"), ["class" => "btn btn-secondary", "data-bs-dismiss" => "modal"])); ?>

			</div>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\qualification\resources\views/crud-maker/components/modal-quickadd.blade.php ENDPATH**/ ?>