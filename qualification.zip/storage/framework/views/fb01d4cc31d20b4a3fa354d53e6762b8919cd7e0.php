<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">

			</div>
			<div class="col-sm-6">
				<div class="text-sm-end d-none d-sm-block">
					
				</div>
			</div>
		</div>
	</div>
</footer><?php /**PATH C:\xampp\htdocs\qualification\resources\views/components/theme/footer.blade.php ENDPATH**/ ?>