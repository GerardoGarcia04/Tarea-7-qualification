<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "name",
		"id" => "name",
		"class" => "form-control",
		"entity" => "courses",
		"type" => "text",
		"defaultValue" => old("name") ?? ($course->name ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\qualification\resources\views/courses/fields.blade.php ENDPATH**/ ?>