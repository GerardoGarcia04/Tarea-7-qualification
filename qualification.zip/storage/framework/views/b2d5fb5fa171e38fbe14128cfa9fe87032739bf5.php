

<?php $__env->startSection('datatable'); ?>
	<?php echo e($dataTable->table(["width" => "100%"])); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud-maker.layouts.index', [
	'title' => __('courses.title_index'), 
	'entity' => 'courses', 
	'form' => 'course',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qualification\resources\views/courses/index.blade.php ENDPATH**/ ?>