<!DOCTYPE html>
<html lang="<?php echo e(setLocale(LC_ALL, env('APP_LOCALE'))); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo e(config('app.name', 'Blank')); ?></title>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<meta name="app-url" content="<?php echo e(env('APP_URL')); ?>">
	
	<?php echo $__env->make('components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
	<!-- Site wrapper -->
	<div class="wrapper">
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="body">
					<div class="row">
						<div class="col-sm-12 col-12">
							<?php echo $__env->yieldContent('content'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
<?php echo $__env->make('components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</html>
<?php /**PATH C:\xampp\htdocs\qualification\resources\views/layouts/guest.blade.php ENDPATH**/ ?>