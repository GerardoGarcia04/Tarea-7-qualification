<?php echo e(Form::hidden($params["data-hidden-id"], $params["data-hidden-value"] ?? "", ['id' => $params["data-hidden-id"]])); ?>

<?php echo e(Form::text($params["name"], $params["defaultValue"] ?? "", $params)); ?><?php /**PATH C:\xampp\htdocs\qualification\resources\views/crud-maker/components/field-autocomplete-input.blade.php ENDPATH**/ ?>