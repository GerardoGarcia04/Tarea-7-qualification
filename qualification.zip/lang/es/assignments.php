<?php
return [
	//Titles
	"title_index" => "Asignaciones",
	"title_add" => "Agregar assignment",
	"title_show" => "Ver assignment",
	"title_edit" => "Modificar assignment",
	"title_delete" => "Eliminar assignment",

	//Fields
	"id" => "id",
	"type" => "Tipo",
	"qualification" => "Calificacion",
	"date" => "Fecha",
	"course_id" => "Curso id",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará assignment de la base de datos. ¿Desea continuar?",
	"Successfully created" => "assignment creado correctamente",
	"Successfully updated" => "assignment modificado correctamente",
	"Successfully deleted" => "assignment eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar assignment de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar assignment, hay tablas que dependen de este",
];