<?php
return [
	"title_index" => "Configuración",

];