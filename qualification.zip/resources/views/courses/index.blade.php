@extends('crud-maker.layouts.index', [
	'title' => __('courses.title_index'), 
	'entity' => 'courses', 
	'form' => 'course',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection