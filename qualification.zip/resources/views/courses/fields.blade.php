@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "name",
		"id" => "name",
		"class" => "form-control",
		"entity" => "courses",
		"type" => "text",
		"defaultValue" => old("name") ?? ($course->name ?? ""),
		"required" => "true",
	]
]])
