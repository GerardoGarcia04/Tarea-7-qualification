@extends('crud-maker.layouts.index', [
	'title' => __('assignments.title_index'), 
	'entity' => 'assignments', 
	'form' => 'assignment',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection