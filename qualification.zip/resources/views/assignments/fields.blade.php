@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "type",
		"id" => "type",
		"class" => "form-control",
		"entity" => "assignments",
		"type" => "text",
		"defaultValue" => old("type") ?? ($assignment->type ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "qualification",
		"id" => "qualification",
		"class" => "form-control",
		"entity" => "assignments",
		"type" => "text",
		"defaultValue" => old("qualification") ?? ($assignment->qualification ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "date",
		"id" => "date",
		"class" => "form-control",
		"entity" => "assignments",
		"type" => "text",
		"defaultValue" => old("date") ?? ($assignment->date ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "course_input",
		"id" => "course_input",
		"class" => "form-control input-autocomplete",
		"entity" => "assignments",
		"type" => "input-autocomplete",
		"defaultValue" => old("course_input") ?? ($assignment->course_input ?? ""),
		"required" => "true",
		"data-source" => "/getbyparam",
		"data-hidden-id" => "course_id",
		"data-hidden-value" => old("course_id") ?? ($assignment->course_id ?? ""),
		"translations" => "assignments.course_id",
	]
]])
