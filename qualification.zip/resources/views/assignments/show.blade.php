@extends('layouts.app', [
	'title' => __('assignments.title_show'), 
])

@section('content')
<div class="report-container p-3">
	<div class="row">
		<div class="col-sm-12 col-md-6 offset-md-3">
			<br>
			<div class="card card-info">
				<div class="card-header">
					<div class="row">
						<div class="col-sm-12 col-md-6 card-title">@lang('assignments.title_show')</div>
						<div class="col-sm-12 col-md-6 text-right">
							<a href="{{ route('assignments.index') }}">
								<i class="fas fa-long-arrow-alt-left"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="card-body">
					
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('assignments.id')</div>
						<div class="col-sm-6">{{ $assignment->id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('assignments.type')</div>
						<div class="col-sm-6">{{ $assignment->type }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('assignments.qualification')</div>
						<div class="col-sm-6">{{ $assignment->qualification }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('assignments.date')</div>
						<div class="col-sm-6">{{ $assignment->date }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('assignments.course_id')</div>
						<div class="col-sm-6">{{ $assignment->course_id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('assignments.created_at')</div>
						<div class="col-sm-6">{{ $assignment->created_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('assignments.updated_at')</div>
						<div class="col-sm-6">{{ $assignment->updated_at }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection