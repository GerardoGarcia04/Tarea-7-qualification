<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Course;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Course::create([
            'name' => 'Diseño de aplicaciones web',
        ]);

        Course::create([
            'name' => 'Animación digital para videojuegos',
        ]);

        Course::create([
            'name' => 'Ingles avanzado 3',
        ]);

        Course::create([
            'name' => 'Ética profesional y ciudadanía',
        ]);
    }
}
