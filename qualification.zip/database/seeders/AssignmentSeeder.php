<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Assignment;

class AssignmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Assignment::create([
            'type' => 'Tarea',
            'qualification' => 90,
            'date' => '2024-03-20',
            'course_id' => '1'
        ]);

        Assignment::create([
            'type' => 'actividad',
            'qualification' => 80,
            'date' => '2024-03-20',
            'course_id' => '1'
        ]);

        Assignment::create([
            'type' => 'prueba rápida',
            'qualification' => 70,
            'date' => '2024-03-20',
            'course_id' => '1'
        ]);

        Assignment::create([
            'type' => 'parcial',
            'qualification' => 70,
            'date' => '2024-03-20',
            'course_id' => '1'
        ]);
    }
}
