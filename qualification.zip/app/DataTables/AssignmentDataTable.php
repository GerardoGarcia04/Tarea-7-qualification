<?php

namespace App\DataTables;

use App\Models\Assignment;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class AssignmentDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'assignments';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Assignment $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('assignments.id')],
			['data' => 'type', 'title' => __('assignments.type')],
			['data' => 'qualification', 'title' => __('assignments.qualification')],
			['data' => 'date', 'title' => __('assignments.date')],
			['data' => 'course_id', 'title' => __('assignments.course_id')],
			['data' => 'created_at', 'visible' => false, 'title' => __('assignments.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('assignments.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
