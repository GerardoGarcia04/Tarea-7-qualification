<?php

namespace App\DataTables;

use App\Models\Course;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class CourseDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'courses';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Course $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('courses.id')],
			['data' => 'name', 'title' => __('courses.name')],
			['data' => 'created_at', 'visible' => false, 'title' => __('courses.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('courses.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
