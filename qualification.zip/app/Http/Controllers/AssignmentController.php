<?php

namespace App\Http\Controllers;

use App\Models\Assignment;

use App\Http\Requests\AssignmentRequest;
use App\DataTables\AssignmentDataTable;
use Illuminate\Http\Request;

class AssignmentController extends Controller
{
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		//Consultar permiso para botón de agregar
		$allowAdd = auth()->user()->hasPermissions("assignments.create");
		$allowEdit = auth()->user()->hasPermissions("assignments.edit");
		return (new AssignmentDataTable())->render('assignments.index', compact('allowAdd', 'allowEdit'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		return view('assignments.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(AssignmentRequest $request)
	{
		$status = true;
		$assignment = null;
		$params = array_merge($request->all(), [
			'created_by' => auth()->id(),
			'updated_by' => auth()->id(),
			'created_at' => date("Y-m-d H:i:s"),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$assignment = Assignment::create($params);
			$message = __('assignments.Successfully created');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'assignments');
		}
		return $this->getResponse($status, $message, $assignment);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  \App\Assignment  $assignment
	 * @return \Illuminate\Http\Response
	 */
	public function show(Assignment $assignment)
	{
		return view('assignments.show', compact('assignment'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  \App\Assignment  $assignment
	 * @return \Illuminate\Http\Response
	 */
	public function edit(Assignment $assignment)
	{
		return view('assignments.edit', compact('assignment'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \App\Assignment  $assignment
	 * @return \Illuminate\Http\Response
	 */
	public function update(AssignmentRequest $request, Assignment $assignment)
	{
		$status = true;
		$params = array_merge($request->all(), [
			'updated_by' => auth()->id(),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$assignment->update($params);
			$message = __('assignments.Successfully updated');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'assignments');
		}
		return $this->getResponse($status, $message, $assignment);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \App\Assignment  $assignment
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(Assignment $assignment)
	{
		$status = true;
		try {
			$assignment->delete();
			$message = __('assignments.Successfully deleted');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'assignments');
		}
		return $this->getResponse($status, $message);
	}

	public function getQuickModalContent(Assignment $assignment = null)
	{
		$params = request("params");
		return response()->json(view('crud-maker.components.modal-quickadd', compact('params', 'assignment'))->render());
	}
}
